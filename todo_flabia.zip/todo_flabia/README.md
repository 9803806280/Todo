# SQLite Data Storage

![Screenshot_1](images/Screenshot_1.png) ![Screenshot_2](images/Screenshot_2.png) ![Screenshot_3](images/Screenshot_3.png) ![Screenshot_4](images/Screenshot_4.png) ![Screenshot_5](images/Screenshot_5.png)

![Screenshot_6](images/Screenshot_6.png) ![Screenshot_7](images/Screenshot_7.png)
