package com.flabia.todo;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Main extends AppCompatActivity {
    EditText mTextUsername;
    EditText mTextPassword;
    Button mButtonLogin;
    DatabaseHelper db;
    ViewGroup progressView;
    protected boolean isProgressShowing = false;    TextView mTextViewRegister;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);



        db = new DatabaseHelper(this);
        mTextUsername=(EditText) findViewById(R.id.edittext_username);
        mTextPassword=(EditText) findViewById(R.id.edittext_password);
        mButtonLogin=(Button) findViewById(R.id.button_login);
        mTextViewRegister=(TextView) findViewById(R.id.textview_register);
        mTextViewRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent registerIntent= new Intent(Main.this,RegisterActivity.class);
                startActivity(registerIntent);
            }
        });
        mButtonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user = mTextUsername.getText().toString().trim();
                String pwd = mTextPassword.getText().toString().trim();
                Boolean res = db.checkUser(user, pwd);
                if(res == true)
                {
                    Intent HomePage = new Intent(Main.this,MainActivity.class);
                    startActivity(HomePage);
                }
                else
                {
                    Toast.makeText(Main.this,"Login Error",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
